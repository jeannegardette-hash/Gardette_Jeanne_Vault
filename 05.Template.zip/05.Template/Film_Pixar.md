---
type: film
studio: Pixar
titre:
annee:
auteur:
realisateur:
personnages_principaux:
duree:
genre:
theme:
saga:
tags:
---

# {{titre}} ({{annee}})

![Affiche du film](URL_DE_LA_PHOTO_ICI)

## Résumé
> Écris ici le résumé du film.

## Easter Eggs
- [Lien vidéo Easter Egg](URL_DE_LA_VIDEO_ICI)
- Liste des easter eggs présents dans le film.

## Informations complémentaires
- **Auteur :** {{auteur}}  
- **Personnages principaux :** {{personnages_principaux}}   
- **Budget :** [à compléter]  
- **Prix et nominations :** [à compléter]  
- **Citations célèbres :** [à compléter]  
- **Objets cultes :** [à compléter]  
- **Lieux clés :** [à compléter]  
- **Musique :** [à compléter]
- **Saga :** {{saga}}  
